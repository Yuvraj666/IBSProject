package com.cg.ibs.loanmgmt.dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import java.util.Map.Entry;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public class CustomerDaoImpl implements CustomerDao {
	public static DataBase base = new DataBase();
	public static Map<String, LoanMaster> loanData = base.getLoanMasterData();
	public static Map<String, CustomerBean> customerData = base.getCustomerBeanData();
	private LoanMaster loanMaster = new LoanMaster();
	private CustomerBean customer = new CustomerBean();

	public LoanMaster updateEMI(LoanMaster loanMaster) {
		loanMaster.setTotalNumberOfEmis(loanMaster.getTotalNumberOfEmis() + 1);
		loanMaster.setNextEmiDate(loanMaster.getNextEmiDate().plusMonths(1));
		loanData.replace(loanMaster.getLoanNumber(), loanMaster);
		return loanMaster;
	}

	public void saveDocument(StringBuilder sb) throws Exception {
		// TODO Auto-generated method stub

	}

	public LoanMaster getEMIDetails(String loanNumber) {
		loanMaster = null;
		if (loanData.containsKey(loanNumber)) {
			loanMaster = loanData.get(loanNumber);
		}
		return loanMaster;

	}

	@Override
	public CustomerBean getCustomerDetails(String userId) {
		customer = null;
		if (customerData.containsKey(userId)) {
			customer = customerData.get(userId);
		}
		return customer;
	}

// LoanDetails
	public List<LoanMaster> getHistory(String userId) { // getting collection of all the loans related to given userID
		List<LoanMaster> loanMasters = new ArrayList<>();

		for (Entry<String, LoanMaster> entry : loanData.entrySet()) {
			if (entry.getValue().getCustomerBean().getUserId().equals(userId)) {
				loanMasters.add(entry.getValue());
			}
		}
		return loanMasters;
	}

//PreClosure
	public LoanMaster getPreClosureLoanDetails(String loanNumber) { // Fetch Loan Details against the loan Number
		loanMaster = null;
		if (loanData.containsKey(loanNumber)) {
			loanMaster = loanData.get(loanNumber); // LoanData HashMap
		}
		
		return loanMaster;
	}

	@Override
	public boolean verifyLoanNumber(String loanNumber) { // Verification of loan Number (PreCLosure)
		boolean check = false;
		if (loanData.containsKey(loanNumber)) {
			check = true;
		}
		return check;
	}

	public boolean sendPreClosureForVerification(LoanMaster loanMaster) throws FileNotFoundException, IOException { // Sending PreClosure Details for verification
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./PreClosureDetails.dat"));
		out.writeObject(loanMaster);

		out.close();
		return true;

	}
}
