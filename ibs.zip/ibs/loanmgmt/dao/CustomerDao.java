package com.cg.ibs.loanmgmt.dao;

import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface CustomerDao {

	public CustomerBean getCustomerDetails(String userId);
	public LoanMaster updateEMI(LoanMaster loanMaster);

	public LoanMaster getEMIDetails(String loanNumber);

	public List<LoanMaster> getHistory(String userId);

	public void saveDocument(StringBuilder sb) throws Exception;

	public LoanMaster getPreClosureLoanDetails(String loanNumber);
	public boolean verifyLoanNumber(String loanNumber);
}