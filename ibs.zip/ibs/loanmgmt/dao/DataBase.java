package com.cg.ibs.loanmgmt.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public class DataBase {

	private static Map<String, LoanMaster> loanMasterData = new HashMap<String, LoanMaster>();
	private static Map<String, CustomerBean> customerBeanData = new HashMap<String, CustomerBean>();
	static {
		CustomerBean customerBean = new CustomerBean("Divyam", "Batta", "12345", "dbatta");
		CustomerBean customerBean1 = new CustomerBean("Chetan", "Kohli", "12346", "ckohli");
		CustomerBean customerBean2 = new CustomerBean("Divyasnh", "Batta", "12347", "dgoyal");
		CustomerBean customerBean3 = new CustomerBean("Yuvraj", "Kalra", "12348", "ykalra");
		CustomerBean customerBean4 = new CustomerBean("yuasa", "rese", "12322", "tatata");

		customerBeanData.put(customerBean.getUserId(), customerBean);
		customerBeanData.put(customerBean1.getUserId(), customerBean1);
		customerBeanData.put(customerBean2.getUserId(), customerBean2);
		customerBeanData.put(customerBean3.getUserId(), customerBean3);
		customerBeanData.put(customerBean4.getUserId(), customerBean4);

		LoanMaster loanMaster = new LoanMaster("997", 2500000.00, 120, 30996.0, customerBean, 60, 120, LocalDate.now(),
				LocalDate.of(2019, 1, 25));
		LoanMaster loanMaster1 = new LoanMaster("998", 1000000.00, 24, 45800.0, customerBean1, 16, 24, LocalDate.now(),
				LocalDate.of(2019, 1, 25));
		LoanMaster loanMaster2 = new LoanMaster("999", 500000.00, 24, 23583.0, customerBean2, 23, 24, LocalDate.now(),
				LocalDate.of(2019, 1, 25));
		LoanMaster loanMaster3 = new LoanMaster("1000", 1000000.00, 60, 46771.0, customerBean3, 50, 60, LocalDate.now(),
				LocalDate.of(2019, 1, 25));
		LoanMaster loanMaster4 = new LoanMaster("996", 2000000.00, 24, 45800.0, customerBean3, 16, 24, LocalDate.now(),
				LocalDate.of(2019, 1, 25));
		LoanMaster loanMaster5 = new LoanMaster("222", 2500000.00, 120, 30996.0, customerBean4, 60, 120,
				LocalDate.now(), LocalDate.of(2019, 1, 25));
		;

		loanMasterData.put(loanMaster.getLoanNumber(), loanMaster);
		loanMasterData.put(loanMaster1.getLoanNumber(), loanMaster1);
		loanMasterData.put(loanMaster2.getLoanNumber(), loanMaster2);
		loanMasterData.put(loanMaster3.getLoanNumber(), loanMaster3);
		loanMasterData.put(loanMaster4.getLoanNumber(), loanMaster4);
		loanMasterData.put(loanMaster5.getLoanNumber(), loanMaster5);

	}

	public static Map<String, LoanMaster> getLoanMasterData() {
		return loanMasterData;
	}

	public static void setLoanMasterData(Map<String, LoanMaster> loanMasterData) {
		DataBase.loanMasterData = loanMasterData;
	}

	public static Map<String, CustomerBean> getCustomerBeanData() {
		return customerBeanData;
	}

	public static void setCustomerBeanData(Map<String, CustomerBean> customerBeanData) {
		DataBase.customerBeanData = customerBeanData;
	}

}
