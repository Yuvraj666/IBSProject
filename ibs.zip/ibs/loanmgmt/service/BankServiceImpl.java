package com.cg.ibs.loanmgmt.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.dao.BankDao;
import com.cg.ibs.loanmgmt.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDao bankDao = new BankDaoImpl();
	LoanMaster loanMaster = new LoanMaster();

	@Override
	public void verifyLoan(LoanMaster loanMaster) throws Exception {
		bankDao.saveLoan(loanMaster);
	}

	public StringBuilder getDocumentsForVerification() throws IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("./Documents.dat"));
		StringBuilder sb = new StringBuilder();
		sb = (StringBuilder) in.readObject();
		in.close();
		return sb;
	}

	public LoanMaster getLoanDetailsForVerification() throws IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("./LoanDetails.dat"));
		loanMaster = (LoanMaster) in.readObject();
		in.close();
		return loanMaster;

	}

	public void downloadDocument(StringBuilder sb) throws Exception {
		bankDao.getDocument(sb);
	}

	public LoanMaster approveLoan(CustomerBean customer, Loan loan, Document document) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean verifyPreClosure(long loanNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean approvePreClosure(LoanMaster loanMaster) {
		return true;
	}

	public LoanMaster getPreClosureDetailsForVerification() throws IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("./PreClosureDetails.dat"));
		loanMaster = (LoanMaster) in.readObject();
		in.close();
		return loanMaster;

	}
	

}
