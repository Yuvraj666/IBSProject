package com.cg.ibs.loanmgmt.dao;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.Map;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public class BankDaoImpl implements BankDao {
	public static DataBase base = new DataBase();
	public static Map<String, LoanMaster> loanData = base.getLoanMasterData();
	public static Map<String, CustomerBean> customerData = base.getCustomerBeanData();
	private LoanMaster loanMaster = new LoanMaster();
	private CustomerBean customer = new CustomerBean();

	public boolean saveLoan(LoanMaster loanMaster) {
		loanData.put(loanMaster.getLoanNumber(), loanMaster);
		return true;
	}

	public boolean savePreClosure(LoanMaster loanMaster) {
		// TODO Auto-generated method stub
		return false;
	}

	public void getDocument(StringBuilder sb) throws Exception {
		BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
				new FileOutputStream("./downloads/DocumentsBankCopy.pdf"));
		bufferedOutputStream.write(sb.toString().getBytes());
		bufferedOutputStream.flush();
		bufferedOutputStream.close();// TODO Auto-generated method stub

	}

}
