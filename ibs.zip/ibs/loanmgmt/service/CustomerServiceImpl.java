package com.cg.ibs.loanmgmt.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.dao.BankDao;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	Loan loan;
	Document document = new Document();
	LoanMaster loanMaster = new LoanMaster();
	CustomerDao customerDao = new CustomerDaoImpl();

	public Loan calculateEmi(Loan loan) {
		float rate = loan.getInterestRate() / (12 * 100);
		loan.setEmiAmount(((loan.getLoanAmount() * rate * Math.pow((rate + 1), loan.getLoanTenure()))
				/ (Math.pow((rate + 1), loan.getLoanTenure()) - 1)));
		return loan;

	}

	public LoanMaster getLoanValues(Loan loan, String userId) {
		loanMaster.setLoanAmount(loan.getLoanAmount());
		loanMaster.setEmiAmount(loan.getEmiAmount());
		loanMaster.setLoanTenure(loan.getLoanTenure());
		loanMaster.setNumberOfEmis(0);
		loanMaster.setAppliedDate(LocalDate.now());
		loanMaster.setNextEmiDate(loanMaster.getAppliedDate().plusMonths(1));
		loanMaster.setCustomerBean(getCustomerDetails(userId));
		loanMaster.setTotalNumberOfEmis(loanMaster.getLoanTenure());
		loanMaster.setLoanNumber(loanMaster.generateLoanNumber());
		loanMaster.setLoanType(loan.getLoanType());
		loanMaster.setInterestRate(loan.getInterestRate());
		return loanMaster;
	}

	private CustomerBean getCustomerDetails(String userId) {
		return customerDao.getCustomerDetails(userId);
	}

	public Loan applyLoan() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean sendLoanForVerification(LoanMaster loanMaster, StringBuilder sb)
			throws FileNotFoundException, IOException {

		ObjectOutputStream out1 = new ObjectOutputStream(new FileOutputStream("./LoanDetails.dat"));
		out1.writeObject(loanMaster);
		ObjectOutputStream out2 = new ObjectOutputStream(new FileOutputStream("./Documents.dat"));
		out2.writeObject(sb);
		out1.close();
		out2.close();
		return true;
	}

	public StringBuilder getDocument(Document document) throws Exception {

		BufferedInputStream bufferedInputStream = new BufferedInputStream(
				new FileInputStream(document.getPathOfDocument()));
		StringBuilder sb = new StringBuilder();
		int ch;
		while ((ch = bufferedInputStream.read()) != -1) {
			sb.append((char) ch);
		}
		bufferedInputStream.close();
		return sb;
	}

	public boolean applyPreClosure(long loanNumber) {

		return false;
	}

	public List<LoanMaster> getHistory(String userId) {
		return customerDao.getHistory(userId);
	}

	public boolean loanCustomerInputVerificationService(Loan loan) {
		boolean amountValid = loan.isValidLoanAmount(loan.getLoanAmount());
		boolean tenureValid = loan.isValidTenure(loan.getLoanTenure());
		boolean check = false;
		if (amountValid & tenureValid) {
			check = true;
		}
		return check;

	}

	private LoanMaster getEMIDetails(String loanNumber) {
		return customerDao.getEMIDetails(loanNumber);

	}

	private boolean verifyEmi(LoanMaster loanMaster) {
		boolean check = false;
		if (loanMaster.getTotalNumberOfEmis() > loanMaster.getNumberOfEmis()) {
			check = true;
		}
		return check;
	}

	public LoanMaster verifyEmiApplicable(String loanNumber) {

		if (verifyEmi(getEMIDetails(loanNumber))) {
			return getEMIDetails(loanNumber);
		} else {
			return null;
		}
	}

	private boolean verifyTransaction(double presentAmount, LoanMaster loanMaster) {

		boolean result = false;
		if (presentAmount == loanMaster.getEmiAmount()) {
			result = true;
		}
		return result;
	}

	public LoanMaster updateEMI(double amountPaid, LoanMaster loanMaster) {
		if (verifyTransaction(amountPaid, loanMaster)) {
			return customerDao.updateEMI(loanMaster);
		} else
			return null;
	}
	
	public LoanMaster updatePreClosure(LoanMaster loanMaster) {
		return customerDao.updateEMI(loanMaster);
	}
	public LoanMaster getPreClosureLoanDetails(String loanNumber) {
		return customerDao.getPreClosureLoanDetails(loanNumber);
	}

	public double calculatePreClosure(String loanNumber) {
		loanMaster = getPreClosureLoanDetails(loanNumber);
		double paidAmount = loanMaster.getNumberOfEmis() * loanMaster.getEmiAmount();
		double paidInterest = loanMaster.getLoanAmount()
				* (Math.pow(1 + loanMaster.getInterestRate()/100, loanMaster.getLoanTenure() / 12));
		double paidPrincipal = paidAmount - paidInterest;
		return loanMaster.getLoanAmount() - paidPrincipal;
	}

	public boolean verifyLoanNumber(String loanNumber) {
		boolean check = false;
		if (customerDao.verifyLoanNumber(loanNumber)) {
			check = verifyPreclosure(getPreClosureLoanDetails(loanNumber));
		}
		return check;
	}

	private boolean verifyPreclosure(LoanMaster loanMaster) {
		boolean check = false;
		if (loanMaster.getNumberOfEmis() > (loanMaster.getTotalNumberOfEmis() / 4)) {
			check = true;

		}
		return check;
	}


	public boolean sendPreClosureForVerification(LoanMaster loanMaster) throws FileNotFoundException, IOException {

		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("./PreClosureDetails.dat"));
		out.writeObject(loanMaster);

		out.close();

		return true;
	}

}
