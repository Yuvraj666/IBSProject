package com.cg.ibs.loanmgmt.ui;

public enum AdminOptions {
	VERIFY_LOAN,VERIFY_PRECLOSURE,APPROVE_LOAN,APPROVE_PRECLOSURE,GO_BACK
}
