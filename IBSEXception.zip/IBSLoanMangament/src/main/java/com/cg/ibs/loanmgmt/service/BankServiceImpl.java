package com.cg.ibs.loanmgmt.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.dao.BankDao;
import com.cg.ibs.loanmgmt.dao.BankDaoImpl;

public class BankServiceImpl implements BankService {
	BankDao bankDao = new BankDaoImpl();
	LoanMaster loanMaster = new LoanMaster();

	public void verifyLoan(LoanMaster loanMaster) throws Exception {
		bankDao.saveLoan(loanMaster);
	}

	public StringBuilder getDocumentsForVerification() throws IOException, ClassNotFoundException {
		return bankDao.getDocumentsForVerification();
	}

	public LoanMaster getLoanDetailsForVerification() throws IOException, ClassNotFoundException {
		return bankDao.getLoanDetailsForVerification();
	}

	public void downloadDocument(StringBuilder sb) throws Exception {
		bankDao.getDocument(sb);
	}

	
	public LoanMaster getPreClosureDetailsForVerification() throws IOException, ClassNotFoundException {
		return bankDao.getPreClosureDetailsForVerification();

	}

	
	public LoanMaster updatePreClosure(LoanMaster loanMaster) {
		return bankDao.updatePreClosure(loanMaster);
	}

}
