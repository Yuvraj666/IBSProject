package com.cg.ibs.loanmgmt.ibsexception;

public class IBSException extends Exception {
	public IBSException (String mssg){
		super (mssg);
	}
	

}
