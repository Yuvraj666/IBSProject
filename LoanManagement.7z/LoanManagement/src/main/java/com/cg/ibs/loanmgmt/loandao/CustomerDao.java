package com.cg.ibs.loanmgmt.loandao;

import java.util.List;

import com.cg.ibs.loanmgmt.bean.LoanMaster;



public interface CustomerDao {
	
	public boolean updateEMI(LoanMaster loanMaster);
	public LoanMaster setEMIDetails(LoanMaster loanMaster);
	public List<LoanMaster> getHistory(String userId);
	public void saveDocument(StringBuilder sb) throws Exception;

}
