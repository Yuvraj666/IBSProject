package com.cg.ibs.loanmgmt.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface CustomerService {
	public Loan applyLoan();

	public Loan calculateEmi(Loan loan);

	public StringBuilder getDocument(Document document) throws Exception;

	public boolean sendLoanForVerification(LoanMaster loanMaster, StringBuilder sb)
			throws FileNotFoundException, IOException;

	public LoanMaster getLoanValues(Loan loan, String userId);

//yuvraj check //	public boolean applyPreClosure(String loanNumber, double preClosureAmount);
	public LoanMaster updatePreClosure(LoanMaster loanMaster);
	public LoanMaster verifyEmiApplicable(String loanNumber);

	public LoanMaster updateEMI(double amountPaid, LoanMaster loanMaster);

//	public LoanMaster payEMI(String loanNumber);

	public List<LoanMaster> getHistory(String userId);

	public boolean loanCustomerInputVerificationService(Loan loan);
	public boolean verifyLoanNumber(String loanNumber);
	
	public LoanMaster getPreClosureLoanDetails(String accountNumber);
	public double calculatePreClosure(String LoanNumber);

	boolean sendPreClosureForVerification(LoanMaster loanMaster) throws FileNotFoundException, IOException;
	

}