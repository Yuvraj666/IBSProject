package com.cg.ibs.loanmgmt.exception;

public interface ExceptionMessages {
	
		public static String messageForWrongInput = "Sorry! Invalid Input.";
		
	
}
