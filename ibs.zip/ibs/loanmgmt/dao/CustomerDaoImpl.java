package com.cg.ibs.loanmgmt.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.service.Loan;

public class CustomerDaoImpl implements CustomerDao {
	public static DataBase base = new DataBase();
	public static Map<String, LoanMaster> loanData = base.getLoanMasterData();
	public static Map<String, CustomerBean> customerData = base.getCustomerBeanData();
	private LoanMaster loanMaster = new LoanMaster();
	private CustomerBean customer = new CustomerBean();

	public LoanMaster updateEMI(LoanMaster loanMaster) {
		loanMaster.setTotalNumberOfEmis(loanMaster.getTotalNumberOfEmis() + 1);
		loanMaster.setNextEmiDate(loanMaster.getNextEmiDate().plusMonths(1));
		loanData.replace(loanMaster.getLoanNumber(), loanMaster);
		return loanMaster;
	}

	public List<LoanMaster> getHistory(String userId) {
		List<LoanMaster> loanMasters = new ArrayList<>();

		for (Entry<String, LoanMaster> entry : loanData.entrySet()) {
			if (entry.getValue().getCustomerBean().getUserId().equals(userId)) {
				loanMasters.add(entry.getValue());
			}
		}
		return loanMasters;
	}

	public void saveDocument(StringBuilder sb) throws Exception {
		// TODO Auto-generated method stub

	}

	public LoanMaster getEMIDetails(String loanNumber) {
		loanMaster = null;
		if (loanData.containsKey(loanNumber)) {
			loanMaster = loanData.get(loanNumber);
		}
		return loanMaster;

	}

	@Override
	public CustomerBean getCustomerDetails(String userId) {
		customer = null;
		if (customerData.containsKey(userId)) {
			customer = customerData.get(userId);
		}
		return customer;
	}
	
	public LoanMaster getPreClosureLoanDetails(String loanNumber) {
		loanMaster = null;
		if (loanData.containsKey(loanNumber)) {
			loanMaster = loanData.get(loanNumber);
		}
		return loanMaster;
	}

	@Override
	public boolean verifyLoanNumber(String loanNumber) {
		boolean check= false ;
		if(loanData.containsKey(loanNumber)) {
			check= true;
		}
		return check;
	}
	
	public LoanMaster updatePreClosure(LoanMaster loanMaster) {
		loanMaster.setNumberOfEmis(loanMaster.getTotalNumberOfEmis());
		loanMaster.setNextEmiDate(null);
		loanData.replace(loanMaster.getLoanNumber(), loanMaster);
		return loanMaster;
	}
}
