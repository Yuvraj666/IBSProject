package com.cg.ibs.loanmgmt.service;

import java.io.IOException;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface BankService {
	public StringBuilder getDocumentsForVerification() throws IOException, ClassNotFoundException;

	public void downloadDocument(StringBuilder sb) throws Exception;

	public LoanMaster getLoanDetailsForVerification() throws IOException, ClassNotFoundException;

	public LoanMaster getPreClosureDetailsForVerification() throws IOException, ClassNotFoundException; //Getting Loan Details 

	public LoanMaster updatePreClosure(LoanMaster loanMaster);

	public void verifyLoan(LoanMaster loanMaster) throws Exception;

}
