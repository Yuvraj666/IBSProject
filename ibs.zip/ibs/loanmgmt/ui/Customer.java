//package com.cg.ibs.loanmgmt.ui;
//
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//import com.cg.ibs.loanmgmt.bean.Document;
//import com.cg.ibs.loanmgmt.bean.LoanMaster;
//import com.cg.ibs.loanmgmt.service.CustomerService;
//import com.cg.ibs.loanmgmt.service.CustomerServiceImpl;
//import com.cg.ibs.loanmgmt.service.EducationLoan;
//import com.cg.ibs.loanmgmt.service.HomeLoan;
//import com.cg.ibs.loanmgmt.service.Loan;
//import com.cg.ibs.loanmgmt.service.PersonalLoan;
//import com.cg.ibs.loanmgmt.service.VehicleLoan;
//
//public class Customer {
//	public static Scanner read;
//	CustomerService customerService = new CustomerServiceImpl();
//	Document document = new Document();
//	Loan loan;
//	LoanMaster loanMaster = new LoanMaster();
//	User user = new User();
//
//	public void init() throws Exception {
//
//		CustomerOptions customerChoice = null;
//		String customerId;
//		while (customerChoice != CustomerOptions.EXIT) {
//			System.out.println("Menu");
//			System.out.println("--------------------");
//			System.out.println("Choice");
//			System.out.println("--------------------");
//			for (CustomerOptions menu : CustomerOptions.values()) {
//				System.out.println((menu.ordinal() + 1) + "\t" + menu);
//			}
//			System.out.println("Choice");
//			int ordinal = read.nextInt();
//			if (ordinal >= 1 && ordinal < (CustomerOptions.values().length) + 1) {
//				customerChoice = CustomerOptions.values()[ordinal - 1];
//				switch (customerChoice) {
//				case APPLY_LOAN:
//					selectLoanType();
//					break;
//				case PAY_EMI:
//					System.out.println("Enter the loan Number : ");
//					payEMI(read.next());
//					break;
//				case APPLY_PRECLOSURE:
//					break;
//				case VIEW_HISTORY:
//					System.out.println(" Enter your customer ID");
//					customerId = read.next();
//					getLoanDetails(customerId);
//					break;
//				case EXIT:
//					System.out.println("Thank You! Come Again.");
//					user.userLogin();
//				}
//
//			} else {
//				System.out.println("Invalid Option.");
//				customerChoice = null;
//			}
//		}
//	}
//
//	private void selectLoanType() throws Exception {
//		LoanTypes choice = null;
//		while (choice != LoanTypes.GO_BACK) {
//			System.out.println("Menu");
//			System.out.println("--------------------");
//			System.out.println("Choice");
//			System.out.println("--------------------");
//			for (LoanTypes menu : LoanTypes.values()) {
//				System.out.println((menu.ordinal() + 1) + "\t" + menu);
//			}
//			System.out.println("Choice");
//			int ordinal = read.nextInt();
//			if (ordinal >= 1 && ordinal < (LoanTypes.values().length) + 1) {
//				choice = LoanTypes.values()[ordinal - 1];
//
//				switch (choice) {
//				case HOME_LOAN:
//					createHomeLoan();
//					break;
//				case EDUCATION_LOAN:
//					createEducationLoan();
//
//					break;
//				case PERSONAL_LOAN:
//					createPersonalLoan();
//					break;
//				case VEHICLE_LOAN:
//					createVehicleLoan();
//					break;
//				case GO_BACK:
//					System.out.println("Thank You!");
//					break;
//				}
//			} else {
//				System.out.println("Invalid Loan Type Selection!!");
//				choice = null;
//
//			}
//
//		}
//
//	}
//
//	private void addLoan(Loan loan) {
//		System.out.println("Would you like to apply for the above Loan ?");
//		System.out.println("1. Yes \n 2. No");
//		switch (read.nextInt()) {
//		case 1: {
//			System.out.println("Welcome to the New Loan Application \n Enter your customer id :- ");
//			try {
//				customerService.sendLoanForVerification(customerService.getLoanValues(loan, read.next()),
//						acceptDocument());
//			} catch (FileNotFoundException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		}
//		case 2: {
//			System.out.println("Thank You!");
//		}
//		}
//	}
//
//	private void createHomeLoan() throws Exception {
//		loan = new HomeLoan();
//		System.out.print("Interest Rate for Home Loan is : ");
//		System.out.println(loan.getInterestRate() + "%");
//		boolean check = false;
//		while (check != true) {
//			System.out.println("Enter the Loan Amount required  : ");
//			System.out.println("***Minimum Loan Limit = 10 Thousand***");
//			System.out.println("***Maximum Loan Limit = 2 Crores***");
//			loan.setLoanAmount(read.nextDouble());
//			System.out.println("Enter the Loan Tenure : ");
//			System.out.println("***Tenure should be in months and multiple of 6***");
//			loan.setLoanTenure(read.nextInt());
//			check = customerService.loanCustomerInputVerificationService(loan);
//			if (check == false) {
//				System.out.println("Invalid inputs");
//			}
//		}
//		loan = customerService.calculateEmi(loan);
//		System.out.println(loan);
//		addLoan(loan);
//	}
//
//	private void createPersonalLoan() throws Exception {
//		loan = new PersonalLoan();
//		System.out.print("Interest Rate for Home Loan is : ");
//		System.out.println(loan.getInterestRate() + "%");
//		boolean check = false;
//		while (check != true) {
//			System.out.println("Enter the Loan Amount required  : ");
//			System.out.println("***Minimum Loan Limit = 10 Thousand***");
//			System.out.println("***Maximum Loan Limit = 2 Crores***");
//			loan.setLoanAmount(read.nextDouble());
//			System.out.println("Enter the Loan Tenure : ");
//			System.out.println("***Tenure should be in months and multiple of 6***");
//			loan.setLoanTenure(read.nextInt());
//			check = customerService.loanCustomerInputVerificationService(loan);
//			if (check == false) {
//				System.out.println("Invalid inputs");
//			}
//		}
//		loan = customerService.calculateEmi(loan);
//		System.out.println(loan);
//		addLoan(loan);
//	}
//
//	private void createVehicleLoan() throws Exception {
//		loan = new VehicleLoan();
//		System.out.print("Interest Rate for Home Loan is : ");
//		System.out.println(loan.getInterestRate() + "%");
//		boolean check = false;
//		while (check != true) {
//			System.out.println("Enter the Loan Amount required  : ");
//			System.out.println("***Minimum Loan Limit = 10 Thousand***");
//			System.out.println("***Maximum Loan Limit = 2 Crores***");
//			loan.setLoanAmount(read.nextDouble());
//			System.out.println("Enter the Loan Tenure : ");
//			System.out.println("***Tenure should be in months and multiple of 6***");
//			loan.setLoanTenure(read.nextInt());
//			check = customerService.loanCustomerInputVerificationService(loan);
//			if (check == false) {
//				System.out.println("Invalid inputs");
//			}
//		}
//		loan = customerService.calculateEmi(loan);
//		System.out.println(loan);
//		addLoan(loan);
//	}
//
//	private void createEducationLoan() throws Exception {
//		loan = new EducationLoan();
//		System.out.print("Interest Rate for Home Loan is : ");
//		System.out.println(loan.getInterestRate() + "%");
//		boolean check = false;
//		while (check != true) {
//			System.out.println("Enter the Loan Amount required  : ");
//			System.out.println("***Minimum Loan Limit = 10 Thousand***");
//			System.out.println("***Maximum Loan Limit = 2 Crores***");
//			loan.setLoanAmount(read.nextDouble());
//			System.out.println("Enter the Loan Tenure : ");
//			System.out.println("***Tenure should be in months and multiple of 6***");
//			loan.setLoanTenure(read.nextInt());
//			check = customerService.loanCustomerInputVerificationService(loan);
//			if (check == false) {
//				System.out.println("Invalid inputs");
//			}
//		}
//		loan = customerService.calculateEmi(loan);
//		System.out.println(loan);
//		addLoan(loan);
//	}
//
//	private StringBuilder acceptDocument() {
//		System.out.println("Enter the name of the document to be uploaded");
//		document.setNameOfDocument(read.next());
//		System.out.println("Enter the path of the document to be uploaded");
//		document.setPathOfDocument(read.next());
//		try {
//			return customerService.getDocument(document);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return null;
//		}
//	}
//
//	private void getLoanDetails(String userId) {
//		List<LoanMaster> loanMasters = new ArrayList<LoanMaster>();
//		// LoanMaster loanMaster = new LoanMaster();
//		loanMasters = customerService.getHistory(userId);
//
//		System.out.println(loanMasters);
//
//	}
//
//	private void payEMI(String loanNumber) {
//
//		loanMaster = customerService.verifyEmiApplicable(loanNumber);
//		if (loanMaster == null) {
//			System.out.println("Loan is either closed or does not exist");
//		} else {
//			System.out.println(loanMaster);
//			System.out.println("Enter the amount to pay EMI ");
//			loanMaster = customerService.updateEMI(read.nextDouble(), loanMaster);
//			if (loanMaster == null) {
//				System.out.println("Transaction Unsuccessful! Try Again");
//			} else {
//				System.out.println("Transaction successful! \n Number Of EMI's left : "
//						+ (loanMaster.getTotalNumberOfEmis() - loanMaster.getNumberOfEmis())
//						+ "\n Next date for EMI payment is : " + loanMaster.getNextEmiDate());
//			}
//		}
//	}
//
//}
