//package com.cg.ibs.loanmgmt.ui;
//
//import java.io.IOException;
//import java.util.Scanner;
//
//import com.cg.ibs.loanmgmt.bean.LoanMaster;
//import com.cg.ibs.loanmgmt.dao.BankDao;
//import com.cg.ibs.loanmgmt.service.BankService;
//import com.cg.ibs.loanmgmt.service.BankServiceImpl;
//
//public class Admin {
//	BankService bankService = new BankServiceImpl();
//	LoanMaster loanMaster = new LoanMaster();
//	Scanner read = new Scanner(System.in);
//	User user = new User();
//	public void adminInit() {
//		AdminOptions adminChoice = null;
//		while(adminChoice != AdminOptions.GO_BACK){
//			System.out.println("Menu");
//			System.out.println("--------------------");
//			System.out.println("Choice");
//			System.out.println("--------------------");
//			for (AdminOptions menu : AdminOptions.values()) {
//				System.out.println((menu.ordinal() + 1) + "\t" + menu);
//			}
//			System.out.println("Choice");
//			int ordinal = read.nextInt();
//			if (ordinal >= 1 && ordinal < (AdminOptions.values().length) + 1) {
//				adminChoice = AdminOptions.values()[ordinal - 1];
//				switch (adminChoice) {
//				case VERIFY_LOAN:
//					verifyLoan();
//					break;
//				case APPROVE_LOAN:
//					break;
//				case VERIFY_PRECLOSURE:
//					break;
//				case APPROVE_PRECLOSURE:
//					break;
//				case GO_BACK:
//				//	System.out.println("Task Completed.");
//					user.userLogin();
//				}
//
//			} else {
//				System.out.println("Invalid Option.");
//				adminChoice = null;
//			}
//		}
//	}
//	public void verifyLoan() {
//		try {
//			loanMaster= bankService.getLoanDetailsForVerification();
//			System.out.println("Downloading Document");
//			bankService.downloadDocument(bankService.getDocumentsForVerification());
//			System.out.println("Application For Loan : " + loanMaster);
//			System.out.println("Document for the above loan has been downloaded in the downloads folder ");
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		
//	}
//	
//	
//
//}
