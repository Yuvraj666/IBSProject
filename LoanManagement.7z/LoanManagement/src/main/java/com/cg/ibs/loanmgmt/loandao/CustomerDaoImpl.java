package com.cg.ibs.loanmgmt.loandao;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public class CustomerDaoImpl implements CustomerDao {
	public static DataBase base=new DataBase();
	public static Map<String,LoanMaster> loanData = base.getLoanMasterData();
	public static Map<String, CustomerBean> customerData = base.getCustomerBeanData();
	public boolean updateEMI(LoanMaster loanMaster) {
			// TODO Auto-generated method stub
		return false;
	}

	public List<LoanMaster> getHistory(String userId) {
		List<LoanMaster> loanMasters = new ArrayList<LoanMaster>(loanData.values());
		List<LoanMaster> customerLoanMasters = new ArrayList<LoanMaster>();
		for (LoanMaster string : customerLoanMasters) {
			System.out.println(string);
		}
//		for (Entry<String, LoanMaster> entry: loanMasterData.entrySet()) {
//			loanMasters.add(entry.getValue());
//			}
		return loanMasters;
	}

	public void saveDocument(StringBuilder sb) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public LoanMaster setEMIDetails(LoanMaster loanMaster) {
		loanMaster.setNumberOfEmis(loanMaster.getNumberOfEmis());
		return loanMaster;
		
	}

	

	
	
	
	
	
	
//	public void saveDocument(StringBuilder sb) throws Exception {
//		BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
//				new FileOutputStream("./downloads/duplicate.pdf"));
//		bufferedOutputStream.write(sb.toString().getBytes());
//		bufferedOutputStream.flush();
//		bufferedOutputStream.close();
//// TODO Auto-generated method stub
//		
//	}

	
}