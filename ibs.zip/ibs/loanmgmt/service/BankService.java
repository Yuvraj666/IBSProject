package com.cg.ibs.loanmgmt.service;

import java.io.IOException;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface BankService {
	public LoanMaster approveLoan(CustomerBean customer, Loan loan, Document document);

	public StringBuilder getDocumentsForVerification() throws IOException, ClassNotFoundException;

	public void downloadDocument(StringBuilder sb) throws Exception;

	public LoanMaster getLoanDetailsForVerification() throws IOException, ClassNotFoundException;

	public boolean verifyPreClosure(long loanNumber);
	public LoanMaster getPreClosureDetailsForVerification() throws IOException, ClassNotFoundException;

	public boolean approvePreClosure(LoanMaster loanMaster);

	void verifyLoan(LoanMaster loanMaster) throws Exception;

}
