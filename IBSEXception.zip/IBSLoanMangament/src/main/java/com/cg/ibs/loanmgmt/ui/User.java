package com.cg.ibs.loanmgmt.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.exception.ExceptionMessages;
import com.cg.ibs.loanmgmt.exception.IBSException;
import com.cg.ibs.loanmgmt.service.BankService;
import com.cg.ibs.loanmgmt.service.BankServiceImpl;
import com.cg.ibs.loanmgmt.service.CustomerService;
import com.cg.ibs.loanmgmt.service.CustomerServiceImpl;
import com.cg.ibs.loanmgmt.service.EducationLoan;
import com.cg.ibs.loanmgmt.service.HomeLoan;
import com.cg.ibs.loanmgmt.service.Loan;
import com.cg.ibs.loanmgmt.service.LoanService;
import com.cg.ibs.loanmgmt.service.LoanServiceImpl;
import com.cg.ibs.loanmgmt.service.PersonalLoan;
import com.cg.ibs.loanmgmt.service.VehicleLoan;

public class User implements ExceptionMessages {
	static Scanner read = new Scanner(System.in);

	public void userLogin() {
		UserOptions choice = null;
		while (choice != UserOptions.EXIT) {
			System.out.println("Enter as existing customer or admin? ");
			System.out.println("--------------------");
			for (UserOptions menu : UserOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (UserOptions.values().length) + 1) {
				choice = UserOptions.values()[ordinal - 1];

				switch (choice) {
				case EXISTING_CUSTOMER:
					try {
						init();
					} catch (Exception exp) {
						exp.printStackTrace();
					}
					break;
				case ADMIN:
					try {
						adminInit();
					} catch (IBSException exp) {
						exp.printStackTrace();
					}
					break;
				case EXIT:
					System.out.println("Have a nice day!");
					break;
				}
			} else {
				choice = null;
				try {
					throw new IBSException(ExceptionMessages.messageForWrongInput);
				} catch (IBSException exp) {
					exp.printStackTrace();
				}

			}

		}

	}

	// CUSTOMER_LOGIN

	static CustomerService customerService = new CustomerServiceImpl();
	Document document = new Document();
	LoanBean loan = new LoanBean();
	LoanMaster loanMaster = new LoanMaster();

	public void init() throws Exception {

		CustomerOptions customerChoice = null;
		String customerId;
		while (customerChoice != CustomerOptions.EXIT) {
			System.out.println("You've entered as an Existing customer :");
			System.out.println("--------------------");
			System.out.println("Please select the following : ");
			System.out.println("--------------------");
			for (CustomerOptions menu : CustomerOptions.values()) {
				System.out.println((menu.ordinal() + 1) + ".\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (CustomerOptions.values().length) + 1) {
				customerChoice = CustomerOptions.values()[ordinal - 1];
				switch (customerChoice) {
				case APPLY_LOAN:
					selectLoanType();
					break;
				case PAY_EMI:
					System.out.println("Enter the loan Number: ");
					payEMI(read.next());
					break;
				case APPLY_PRECLOSURE:
					applyPreClosure();
					break;
				case VIEW_HISTORY:
					System.out.println(" Enter your customer ID: ");
					getLoanDetails(read.next());
					break;
				case EXIT:
					System.out.println("Thank You! Come Again.");
					userLogin();
				}

			} else {
				customerChoice = null;
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}
	}

	private void selectLoanType() throws IBSException {
		LoanTypes choice = null;
		while (choice != LoanTypes.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (LoanTypes menu : LoanTypes.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (LoanTypes.values().length) + 1) {
				choice = LoanTypes.values()[ordinal - 1];

				switch (choice) {
				case HOME_LOAN:
					createHomeLoan();
					break;
				case EDUCATION_LOAN:
					createEducationLoan();
					break;
				case PERSONAL_LOAN:
					createPersonalLoan();
					break;
				case VEHICLE_LOAN:
					createVehicleLoan();
					break;
				case GO_BACK:
					System.out.println("Thank You!");
					break;
				}
			} else {
				choice = null;
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}

		}

	}

	private void addLoan(LoanBean loanBean) {
		LoanService loanService = new LoanServiceImpl();
		System.out.println("Would you like to apply for the above Loan ?");
		System.out.println("1. Yes \n 2. No");
		switch (read.nextInt()) {
		case 1: {
			System.out.println("Welcome to the New Loan Application \n Enter your customer id :- ");
			try {
				customerService.sendLoanForVerification(
						customerService.getLoanValues(loanService.setLoanDetails(loanBean), read.next()),
						acceptDocument());
			} catch (FileNotFoundException exp) {

				exp.printStackTrace();
			} catch (IOException exp) {
				exp.printStackTrace();
			}

		}
		case 2: {
			System.out.println("Thank You!");
		}
		}
	}

	private void createHomeLoan() throws IBSException {
		LoanService loanService = new LoanServiceImpl();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println("8.5 %");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 2 Crores***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			loan.setLoanType(LoanType.HOME_LOAN);
			loan.setInterestRate(8.5f);
			check = customerService.loanCustomerInputVerificationService(loanService.setLoanDetails(loan));
			if (check == false) {
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}

		loan.setEmiAmount(customerService.calculateEmi(loanService.setLoanDetails(loan)));
		System.out.println(loan);
		addLoan(loan);
	}

	private void createPersonalLoan() throws IBSException {
		LoanService loanService = new LoanServiceImpl();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println("10.75 %");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 20 Lakhs***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			loan.setLoanType(LoanType.PERSONAL_LOAN);
			loan.setInterestRate(10.75f);
			check = customerService.loanCustomerInputVerificationService(loanService.setLoanDetails(loan));
			if (check == false) {
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}

		loan.setEmiAmount(customerService.calculateEmi(loanService.setLoanDetails(loan)));
		System.out.println(loan);
		addLoan(loan);
	}

	private void createVehicleLoan() throws IBSException {
		LoanService loanService = new LoanServiceImpl();
		System.out.print("Interest Rate for Vehicle Loan is : ");
		System.out.println("9.25 %");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 30 Lakhs***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			loan.setLoanType(LoanType.VEHICLE_LOAN);
			loan.setInterestRate(9.25f);
			check = customerService.loanCustomerInputVerificationService(loanService.setLoanDetails(loan));
			if (check == false) {
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}

		loan.setEmiAmount(customerService.calculateEmi(loanService.setLoanDetails(loan)));
		System.out.println(loan);
		addLoan(loan);
	}

	private void createEducationLoan() throws IBSException {
		LoanService loanService = new LoanServiceImpl();
		System.out.print("Interest Rate for Vehicle Loan is : ");
		System.out.println("11.35 %");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 50 Lakhs***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			loan.setLoanType(LoanType.EDUCATION_LOAN);
			loan.setInterestRate(11.35f);
			check = customerService.loanCustomerInputVerificationService(loanService.setLoanDetails(loan));
			if (check == false) {
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}

		loan.setEmiAmount(customerService.calculateEmi(loanService.setLoanDetails(loan)));
		System.out.println(loan);
		addLoan(loan);
	}

	private StringBuilder acceptDocument() {
		System.out.println("Enter the name of the document to be uploaded");
		document.setNameOfDocument(read.next());
		System.out.println("Enter the path of the document to be uploaded");
		document.setPathOfDocument(read.next());
		try {
			return customerService.getDocument(document);
		} catch (Exception exp) {
			exp.printStackTrace();
			return null;
		}
	}

	private void getLoanDetails(String userId) {
		List<LoanMaster> loanMasters = new ArrayList<LoanMaster>();
		loanMasters = customerService.getHistory(userId); // getting collection
															// of all the loans
															// realted to given
															// userID
		System.out.println(loanMasters);

	}

	private void payEMI(String loanNumber) {

		loanMaster = customerService.verifyEmiApplicable(loanNumber);
		if (loanMaster == null) {
			System.out.println("Loan is either closed or does not exist");
		} else {
			System.out.println(loanMaster);
			System.out.println("Enter the amount to pay EMI ");
			loanMaster = customerService.updateEMI(read.nextDouble(), loanMaster);
			if (loanMaster == null) {
				System.out.println("Transaction Unsuccessful! Try Again");
			} else {
				System.out.println("Transaction successful! \n Number Of EMI's left : "
						+ (loanMaster.getTotalNumberOfEmis() - loanMaster.getNumberOfEmis())
						+ "\n Next date for EMI payment is : " + loanMaster.getNextEmiDate());
			}
		}
	}

	private void applyPreClosure() {
		System.out.println("Enter the Loan Number :");
		String loanNumber = read.next();
		boolean check = customerService.verifyLoanNumber(loanNumber); // Verification
																		// of
																		// existence
																		// in DB
																		// and
																		// verification
																		// of
																		// preliminary
																		// applicability
																		// condition
		if (check) {
			System.out.println("Your Loan against Loan Number : " + loanNumber
					+ " is applicable for PreClosure. Following are the details of the loan :");
			loanMaster = customerService.getPreClosureLoanDetails(loanNumber);
			System.out.println(loanMaster);
			System.out.println("The amount for PreClosure is: INR  " + customerService.calculatePreClosure(loanMaster));
			System.out.println("\nDo you want to pay the amount? \n1. Yes\n2. No");
			switch (read.nextInt()) {
			case 1:
				try {
					if (customerService.sendPreClosureForVerification(loanMaster)) {
						System.out.println("Thank You!\n Your loan has been sent for verification.");
					}
				} catch (IOException exp) {
					exp.printStackTrace();
				}
			case 2:
				try {
					init();
				} catch (Exception exp) {
					exp.printStackTrace();
				}
			}
		} else {
			System.out.println("Loan with Loan Number : " + loanNumber + " does not exist");
		}
	}

	// ADMIN_LOGIN

	BankService bankService = new BankServiceImpl();

	public void adminInit() throws IBSException {
		AdminOptions adminChoice = null;
		while (adminChoice != AdminOptions.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (AdminOptions menu : AdminOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (AdminOptions.values().length) + 1) {
				adminChoice = AdminOptions.values()[ordinal - 1];
				switch (adminChoice) {
				case VERIFY_LOAN:
					verifyLoan();
					break;
				case VERIFY_PRECLOSURE:
					verifyPreClosure();
					break;
				case GO_BACK:
					userLogin();
				}

			} else {
				adminChoice = null;
				throw new IBSException(ExceptionMessages.messageForWrongInput);
			}
		}
	}

	public void verifyLoan() {
		try {
			loanMaster = bankService.getLoanDetailsForVerification();
			System.out.println("Downloading Document");
			bankService.downloadDocument(bankService.getDocumentsForVerification());
			System.out.println("Application For Loan : " + loanMaster);
			System.out.println("Document for the above loan has been downloaded in the downloads folder ");
			System.out.println("Verification Response : ");
			System.out.println("1. Approve Loan /n 2. Decline Loan");
			switch (read.nextInt()) {
			case 1:
				bankService.verifyLoan(loanMaster);
				break;
			case 2:
				adminInit();
				break;
			}
		} catch (Exception exp) {
			exp.printStackTrace();
		}

	}

	public void verifyPreClosure() throws IBSException {
		try {
			loanMaster = bankService.getPreClosureDetailsForVerification(); // fetch
																			// Data
																			// for
																			// verification
		} catch (ClassNotFoundException | IOException exp) {
			exp.printStackTrace();
		}
		System.out.println("Pre-Closure application For Loan : " + loanMaster);
		System.out.println("\n1. Approve Loan \n2. Decline Loan");
		switch (read.nextInt()) {
		case 1:
			try {
				bankService.updatePreClosure(loanMaster);
				System.out.println("Preclosure for Loan Number : " + loanMaster.getLoanNumber()
						+ "has been approved and updated.");
			} catch (Exception exp) {
				exp.printStackTrace();
			}
			break;
		case 2:
			System.out.println("PreClosure for Loan Number : " + loanMaster.getLoanNumber() + "has been declined.");
			adminInit();
			break;
		}
	}

	public static void main(String[] args) throws IBSException {
		User user = new User();
		user.userLogin();
	}

}
