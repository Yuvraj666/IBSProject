package com.cg.ibs.loanmgmt.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.service.BankService;
import com.cg.ibs.loanmgmt.service.BankServiceImpl;
import com.cg.ibs.loanmgmt.service.CustomerService;
import com.cg.ibs.loanmgmt.service.CustomerServiceImpl;
import com.cg.ibs.loanmgmt.service.EducationLoan;
import com.cg.ibs.loanmgmt.service.HomeLoan;
import com.cg.ibs.loanmgmt.service.Loan;
import com.cg.ibs.loanmgmt.service.PersonalLoan;
import com.cg.ibs.loanmgmt.service.VehicleLoan;

public class User {
	static Scanner read = new Scanner(System.in);

	public void userLogin() {
		System.out.println("Are you a customer or bank representative ?");
		System.out.println("1. Customer \n2. Admin");
		switch (read.nextInt()) {
		case 1: {
			try {
				init();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		case 2: {
			adminInit();
		}
			read.close();
		}
	}

	// CUSTOMER_LOGIN

	CustomerService customerService = new CustomerServiceImpl();
	Document document = new Document();
	Loan loan;
	LoanMaster loanMaster = new LoanMaster();

	public void init() throws Exception {

		CustomerOptions customerChoice = null;
		String customerId;
		while (customerChoice != CustomerOptions.EXIT) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (CustomerOptions menu : CustomerOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (CustomerOptions.values().length) + 1) {
				customerChoice = CustomerOptions.values()[ordinal - 1];
				switch (customerChoice) {
				case APPLY_LOAN:
					selectLoanType();
					break;
				case PAY_EMI:
					System.out.println("Enter the loan Number : ");
					payEMI(read.next());
					break;
				case APPLY_PRECLOSURE:
					applyPreClosure();
					break;
				case VIEW_HISTORY:
					System.out.println(" Enter your customer ID");
					customerId = read.next();
					getLoanDetails(customerId);
					break;
				case EXIT:
					System.out.println("Thank You! Come Again.");
					userLogin();
				}

			} else {
				System.out.println("Invalid Option.");
				customerChoice = null;
			}
		}
	}

	private void selectLoanType() throws Exception {
		LoanTypes choice = null;
		while (choice != LoanTypes.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (LoanTypes menu : LoanTypes.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (LoanTypes.values().length) + 1) {
				choice = LoanTypes.values()[ordinal - 1];

				switch (choice) {
				case HOME_LOAN:
					createHomeLoan();
					break;
				case EDUCATION_LOAN:
					createEducationLoan();

					break;
				case PERSONAL_LOAN:
					createPersonalLoan();
					break;
				case VEHICLE_LOAN:
					createVehicleLoan();
					break;
				case GO_BACK:
					System.out.println("Thank You!");
					break;
				}
			} else {
				System.out.println("Invalid Loan Type Selection!!");
				choice = null;

			}

		}

	}

	private void addLoan(Loan loan) {
		System.out.println("Would you like to apply for the above Loan ?");
		System.out.println("1. Yes \n 2. No");
		switch (read.nextInt()) {
		case 1: {
			System.out.println("Welcome to the New Loan Application \n Enter your customer id :- ");
			try {
				customerService.sendLoanForVerification(customerService.getLoanValues(loan, read.next()),
						acceptDocument());
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		case 2: {
			System.out.println("Thank You!");
		}
		}
	}

	private void createHomeLoan() throws Exception {
		loan = new HomeLoan();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println(loan.getInterestRate() + "%");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 2 Crores***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			check = customerService.loanCustomerInputVerificationService(loan);
			if (check == false) {
				System.out.println("Invalid inputs");
			}
		}
		loan = customerService.calculateEmi(loan);
		System.out.println(loan);
		addLoan(loan);
	}

	private void createPersonalLoan() throws Exception {
		loan = new PersonalLoan();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println(loan.getInterestRate() + "%");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 2 Crores***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			check = customerService.loanCustomerInputVerificationService(loan);
			if (check == false) {
				System.out.println("Invalid inputs");
			}
		}
		loan = customerService.calculateEmi(loan);
		System.out.println(loan);
		addLoan(loan);
	}

	private void createVehicleLoan() throws Exception {
		loan = new VehicleLoan();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println(loan.getInterestRate() + "%");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 2 Crores***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			check = customerService.loanCustomerInputVerificationService(loan);
			if (check == false) {
				System.out.println("Invalid inputs");
			}
		}
		loan = customerService.calculateEmi(loan);
		System.out.println(loan);
		addLoan(loan);
	}

	private void createEducationLoan() throws Exception {
		loan = new EducationLoan();
		System.out.print("Interest Rate for Home Loan is : ");
		System.out.println(loan.getInterestRate() + "%");
		boolean check = false;
		while (check != true) {
			System.out.println("Enter the Loan Amount required  : ");
			System.out.println("***Minimum Loan Limit = 10 Thousand***");
			System.out.println("***Maximum Loan Limit = 2 Crores***");
			loan.setLoanAmount(read.nextDouble());
			System.out.println("Enter the Loan Tenure : ");
			System.out.println("***Tenure should be in months and multiple of 6***");
			loan.setLoanTenure(read.nextInt());
			check = customerService.loanCustomerInputVerificationService(loan);
			if (check == false) {
				System.out.println("Invalid inputs");
			}
		}
		loan = customerService.calculateEmi(loan);
		System.out.println(loan);
		addLoan(loan);
	}

	private StringBuilder acceptDocument() {
		System.out.println("Enter the name of the document to be uploaded");
		document.setNameOfDocument(read.next());
		System.out.println("Enter the path of the document to be uploaded");
		document.setPathOfDocument(read.next());
		try {
			return customerService.getDocument(document);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private void getLoanDetails(String userId) {
		List<LoanMaster> loanMasters = new ArrayList<LoanMaster>();
		// LoanMaster loanMaster = new LoanMaster();
		loanMasters = customerService.getHistory(userId);

		System.out.println(loanMasters);

	}

	private void payEMI(String loanNumber) {

		loanMaster = customerService.verifyEmiApplicable(loanNumber);
		if (loanMaster == null) {
			System.out.println("Loan is either closed or does not exist");
		} else {
			System.out.println(loanMaster);
			System.out.println("Enter the amount to pay EMI ");
			loanMaster = customerService.updateEMI(read.nextDouble(), loanMaster);
			if (loanMaster == null) {
				System.out.println("Transaction Unsuccessful! Try Again");
			} else {
				System.out.println("Transaction successful! \n Number Of EMI's left : "
						+ (loanMaster.getTotalNumberOfEmis() - loanMaster.getNumberOfEmis())
						+ "\n Next date for EMI payment is : " + loanMaster.getNextEmiDate());
			}
		}
	}

	private void applyPreClosure() {
		System.out.println("Enter the Loan Number ");
		String loanNumber = read.next();
		boolean check = customerService.verifyLoanNumber(loanNumber);
		if (check) {
			System.out.println("Your Loan is applicable for PreClosure. Following are the details of the loan :");
			loanMaster = customerService.getPreClosureLoanDetails(loanNumber);
			System.out.println(loanMaster);
			System.out.println("The amount for PreClosure is INR  " + customerService.calculatePreClosure(loanNumber));
			System.out.println("Do you want to pay the amount? \n1. Yes\n2. No");
			switch (read.nextInt()) {
			case 1:
				System.out.println("Enter the amount to be paid:");
				try {
					if (customerService.sendPreClosureForVerification(loanMaster)) {
						System.out.println("Thank You! Your loan has been sent for verification.");
						// yuvraj check here some function will be there or not
						System.out.println("Your loan has been shut down.");
						customerService.updatePreClosure(loanMaster);
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			case 2:
				try {
					init();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	// ADMIN_LOGIN

	BankService bankService = new BankServiceImpl();

	public void adminInit() {
		AdminOptions adminChoice = null;
		while (adminChoice != AdminOptions.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (AdminOptions menu : AdminOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = read.nextInt();
			if (ordinal >= 1 && ordinal < (AdminOptions.values().length) + 1) {
				adminChoice = AdminOptions.values()[ordinal - 1];
				switch (adminChoice) {
				case VERIFY_LOAN:
					verifyLoan();
					break;
				case APPROVE_LOAN:
					break;
				case VERIFY_PRECLOSURE:
					break;
				case APPROVE_PRECLOSURE:
					break;
				case GO_BACK:
					// System.out.println("Task Completed.");
					userLogin();
				}

			} else {
				System.out.println("Invalid Option.");
				adminChoice = null;
			}
		}
	}

	public void verifyLoan() {
		try {
			loanMaster = bankService.getLoanDetailsForVerification();
			System.out.println("Downloading Document");
			bankService.downloadDocument(bankService.getDocumentsForVerification());
			System.out.println("Application For Loan : " + loanMaster);
			System.out.println("Document for the above loan has been downloaded in the downloads folder ");
			System.out.println("Verification Response : ");
			System.out.println("1. Approve Loan /n 2. Decline Loan");
			switch (read.nextInt()) {
			case 1:
				bankService.verifyLoan(loanMaster);
				break;
			case 2:
				adminInit();
				break;
			}
//			if (read.nextInt() == 1) {
//				bankService.verifyLoan(loanMaster);
//			} else if (read.nextInt() == 2) {
//
//			} else {
//				System.out.println("Invalid Input");
//			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void verifyPreClosure() {
		try {
			loanMaster = bankService.getPreClosureDetailsForVerification();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Pre-Closure application For Loan : " + loanMaster);
		System.out.println("1. Approve Loan /n 2. Decline Loan");
		switch (read.nextInt()) {
		case 1:
			try {
				bankService.verifyLoan(loanMaster);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			adminInit();
			break;
		}
	}

	public static void main(String[] args) throws Exception {
		User user = new User();
		user.userLogin();
	}

}
