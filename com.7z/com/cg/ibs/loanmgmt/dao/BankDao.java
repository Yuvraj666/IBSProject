package com.cg.ibs.loanmgmt.dao;

import java.io.IOException;

import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface BankDao {
	public boolean saveLoan(LoanMaster loanMaster);
	public StringBuilder getDocumentsForVerification() throws IOException, ClassNotFoundException;
	public LoanMaster getLoanDetailsForVerification() throws IOException, ClassNotFoundException;

	public void getDocument(StringBuilder sb) throws Exception;

	public LoanMaster getPreClosureDetailsForVerification() throws IOException, ClassNotFoundException; //Fetch Loan Details Pending for verification

	public LoanMaster updatePreClosure(LoanMaster loanMaster); //Updates Loan Details

}
